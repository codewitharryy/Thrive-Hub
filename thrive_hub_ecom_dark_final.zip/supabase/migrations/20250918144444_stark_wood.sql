/*
# Thrive Hub Database Schema

1. New Tables
   - `user_profiles` - Extended user information including physical stats, preferences, and goals
   - `communities` - Community groups for students and professionals
   - `trainers` - Professional trainers available on the platform
   - `resources` - Articles, blogs, videos for wellness education
   - `user_activities` - Track user engagement and activities
   - `user_points` - Points and achievements system
   - `chat_messages` - AI chatbot conversation history
   - `user_communities` - Junction table for user-community relationships
   - `trainer_sessions` - Training sessions offered by trainers

2. Security
   - Enable RLS on all tables
   - Add policies for authenticated users to manage their own data
   - Public read access for resources and trainers
   - Community-based access for community features

3. Features
   - Automatic BMI calculation
   - Gender-based content adaptation
   - Points tracking and gamification
   - Real-time activity monitoring
*/

-- User Profiles Extension
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  age integer,
  height_cm integer,
  weight_kg numeric(5,2),
  bmi numeric(4,1) GENERATED ALWAYS AS (
    CASE 
      WHEN height_cm > 0 THEN ROUND((weight_kg / ((height_cm/100.0) * (height_cm/100.0)))::numeric, 1)
      ELSE NULL
    END
  ) STORED,
  gender text CHECK (gender IN ('male', 'female', 'other')),
  profession text,
  date_of_birth date,
  location text,
  fitness_goal text,
  activity_level text DEFAULT 'moderate',
  theme_preference text DEFAULT 'light' CHECK (theme_preference IN ('light', 'dark')),
  profile_completed boolean DEFAULT false,
  total_points integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Communities Table
CREATE TABLE IF NOT EXISTS communities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  category text CHECK (category IN ('students', 'professionals', 'fitness', 'mental_health', 'nutrition')),
  member_count integer DEFAULT 0,
  is_public boolean DEFAULT true,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

-- User Communities Junction Table
CREATE TABLE IF NOT EXISTS user_communities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  community_id uuid REFERENCES communities(id) ON DELETE CASCADE,
  role text DEFAULT 'member' CHECK (role IN ('member', 'moderator', 'admin')),
  joined_at timestamptz DEFAULT now(),
  UNIQUE(user_id, community_id)
);

-- Trainers Table
CREATE TABLE IF NOT EXISTS trainers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  specialization text[],
  experience_years integer,
  bio text,
  hourly_rate numeric(8,2),
  rating numeric(3,1) DEFAULT 0,
  total_sessions integer DEFAULT 0,
  is_verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Resources Table
CREATE TABLE IF NOT EXISTS resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text,
  type text CHECK (type IN ('article', 'video', 'blog', 'workout', 'recipe')),
  category text,
  tags text[],
  author_id uuid REFERENCES auth.users(id),
  target_gender text CHECK (target_gender IN ('male', 'female', 'all')),
  difficulty_level text DEFAULT 'beginner' CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
  duration_minutes integer,
  is_published boolean DEFAULT false,
  view_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- User Activities Tracking
CREATE TABLE IF NOT EXISTS user_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  activity_type text NOT NULL,
  activity_data jsonb,
  points_earned integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- User Points System
CREATE TABLE IF NOT EXISTS user_points (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  points integer NOT NULL,
  source text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Chat Messages
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  message text NOT NULL,
  response text,
  message_type text DEFAULT 'user' CHECK (message_type IN ('user', 'ai')),
  created_at timestamptz DEFAULT now()
);

-- Trainer Sessions
CREATE TABLE IF NOT EXISTS trainer_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trainer_id uuid REFERENCES trainers(id) ON DELETE CASCADE,
  client_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  session_date timestamptz,
  duration_minutes integer DEFAULT 60,
  price numeric(8,2),
  status text DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

-- Insert some default communities
INSERT INTO communities (name, description, category, is_public) VALUES
('Student Wellness', 'A community for students focusing on academic stress management and healthy habits', 'students', true),
('Professional Fitness', 'Working professionals sharing fitness tips and work-life balance strategies', 'professionals', true),
('Mental Health Support', 'Safe space for mental health discussions and support', 'mental_health', true),
('Nutrition Corner', 'Share healthy recipes and nutrition tips', 'nutrition', true),
('Home Workouts', 'Quick and effective workouts you can do at home', 'fitness', true);

-- Insert sample resources
INSERT INTO resources (title, content, type, category, tags, target_gender, difficulty_level, duration_minutes, is_published) VALUES
('Morning Stretches for Better Posture', 'Start your day with these simple stretches to improve posture and reduce back pain from desk work.', 'article', 'fitness', ARRAY['stretching', 'posture', 'morning'], 'all', 'beginner', 10, true),
('Healthy Meal Prep for Busy Students', 'Learn how to prepare nutritious meals in advance to save time and money while maintaining a healthy diet.', 'blog', 'nutrition', ARRAY['meal_prep', 'student_life', 'budget_friendly'], 'all', 'beginner', 30, true),
('Stress Management Techniques', 'Effective methods to manage stress and anxiety in academic and professional settings.', 'article', 'mental_health', ARRAY['stress', 'anxiety', 'mindfulness'], 'all', 'beginner', 15, true),
('HIIT Workout for Women', 'High-intensity interval training designed specifically for women, adaptable to different fitness levels.', 'workout', 'fitness', ARRAY['hiit', 'cardio', 'strength'], 'female', 'intermediate', 25, true),
('Building Muscle: A Beginner Guide for Men', 'Complete guide to starting your muscle building journey with proper form and nutrition.', 'article', 'fitness', ARRAY['muscle_building', 'strength', 'nutrition'], 'male', 'beginner', 20, true);

-- Enable Row Level Security
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE communities ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_communities ENABLE ROW LEVEL SECURITY;
ALTER TABLE trainers ENABLE ROW LEVEL SECURITY;
ALTER TABLE resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_points ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE trainer_sessions ENABLE ROW LEVEL SECURITY;

-- User Profiles Policies
CREATE POLICY "Users can read own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Communities Policies
CREATE POLICY "Anyone can read public communities"
  ON communities
  FOR SELECT
  TO authenticated
  USING (is_public = true);

CREATE POLICY "Users can create communities"
  ON communities
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

-- User Communities Policies
CREATE POLICY "Users can read their community memberships"
  ON user_communities
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can join communities"
  ON user_communities
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Resources Policies
CREATE POLICY "Anyone can read published resources"
  ON resources
  FOR SELECT
  TO authenticated
  USING (is_published = true);

CREATE POLICY "Authors can manage their resources"
  ON resources
  FOR ALL
  TO authenticated
  USING (auth.uid() = author_id);

-- Trainers Policies
CREATE POLICY "Anyone can read verified trainers"
  ON trainers
  FOR SELECT
  TO authenticated
  USING (is_verified = true);

CREATE POLICY "Users can create trainer profile"
  ON trainers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Trainers can update own profile"
  ON trainers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- User Activities Policies
CREATE POLICY "Users can read own activities"
  ON user_activities
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own activities"
  ON user_activities
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- User Points Policies
CREATE POLICY "Users can read own points"
  ON user_points
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "System can insert points"
  ON user_points
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Chat Messages Policies
CREATE POLICY "Users can read own chat messages"
  ON chat_messages
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own chat messages"
  ON chat_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Trainer Sessions Policies
CREATE POLICY "Users can read their trainer sessions"
  ON trainer_sessions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = client_id OR auth.uid() IN (SELECT user_id FROM trainers WHERE id = trainer_id));

CREATE POLICY "Users can book trainer sessions"
  ON trainer_sessions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = client_id);

-- Functions to update community member count
CREATE OR REPLACE FUNCTION update_community_member_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE communities 
    SET member_count = member_count + 1 
    WHERE id = NEW.community_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE communities 
    SET member_count = member_count - 1 
    WHERE id = OLD.community_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Trigger for community member count
CREATE TRIGGER update_community_member_count_trigger
  AFTER INSERT OR DELETE ON user_communities
  FOR EACH ROW EXECUTE FUNCTION update_community_member_count();

-- Function to update user total points
CREATE OR REPLACE FUNCTION update_user_total_points()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE user_profiles 
  SET total_points = (
    SELECT COALESCE(SUM(points), 0) 
    FROM user_points 
    WHERE user_id = NEW.user_id
  )
  WHERE id = NEW.user_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for user total points
CREATE TRIGGER update_user_total_points_trigger
  AFTER INSERT ON user_points
  FOR EACH ROW EXECUTE FUNCTION update_user_total_points();