import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project-ref.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key-here'

if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
  console.warn('Supabase environment variables are not set. Please configure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your .env file.')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string
          full_name: string
          age: number | null
          height_cm: number | null
          weight_kg: number | null
          bmi: number | null
          gender: 'male' | 'female' | 'other' | null
          profession: string | null
          date_of_birth: string | null
          location: string | null
          fitness_goal: string | null
          activity_level: string
          theme_preference: 'light' | 'dark'
          profile_completed: boolean
          total_points: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          full_name: string
          age?: number | null
          height_cm?: number | null
          weight_kg?: number | null
          gender?: 'male' | 'female' | 'other' | null
          profession?: string | null
          date_of_birth?: string | null
          location?: string | null
          fitness_goal?: string | null
          activity_level?: string
          theme_preference?: 'light' | 'dark'
          profile_completed?: boolean
          total_points?: number
        }
        Update: {
          full_name?: string
          age?: number | null
          height_cm?: number | null
          weight_kg?: number | null
          gender?: 'male' | 'female' | 'other' | null
          profession?: string | null
          date_of_birth?: string | null
          location?: string | null
          fitness_goal?: string | null
          activity_level?: string
          theme_preference?: 'light' | 'dark'
          profile_completed?: boolean
          total_points?: number
        }
      }
      communities: {
        Row: {
          id: string
          name: string
          description: string | null
          category: string | null
          member_count: number
          is_public: boolean
          created_by: string | null
          created_at: string
        }
      }
      resources: {
        Row: {
          id: string
          title: string
          content: string | null
          type: string | null
          category: string | null
          tags: string[] | null
          author_id: string | null
          target_gender: string | null
          difficulty_level: string
          duration_minutes: number | null
          is_published: boolean
          view_count: number
          created_at: string
          updated_at: string
        }
      }
      trainers: {
        Row: {
          id: string
          user_id: string
          specialization: string[] | null
          experience_years: number | null
          bio: string | null
          hourly_rate: number | null
          rating: number
          total_sessions: number
          is_verified: boolean
          created_at: string
        }
      }
      user_activities: {
        Row: {
          id: string
          user_id: string
          activity_type: string
          activity_data: any | null
          points_earned: number
          created_at: string
        }
      }
      user_points: {
        Row: {
          id: string
          user_id: string
          points: number
          source: string
          description: string | null
          created_at: string
        }
      }
      chat_messages: {
        Row: {
          id: string
          user_id: string
          message: string
          response: string | null
          message_type: 'user' | 'ai'
          created_at: string
        }
      }
    }
  }
}