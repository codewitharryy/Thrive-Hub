import React from "react";

export default function ProductCard({p, onAdd}){
  return (
    <div className="bg-gray-800/60 border border-gray-700 rounded-xl p-4 flex flex-col hover:scale-105 transform transition">
      <div className="h-40 flex items-center justify-center mb-3">
        <img src={p.image} alt={p.title} className="max-h-36" onError={(e)=>{e.currentTarget.style.display='none'}}/>
      </div>
      <div className="flex-1">
        <h3 className="text-lg font-semibold text-white">{p.title}</h3>
        <p className="text-sm text-gray-300 mt-2">{p.desc}</p>
      </div>
      <div className="mt-4 flex items-center justify-between">
        <div className="text-emerald-400 font-bold">₹{p.price}</div>
        <button onClick={()=>onAdd(p)} className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-md text-white shadow-md">Add</button>
      </div>
    </div>
  )
}