import React from "react";
import { useCart } from "../../contexts/CartContext";
import { useState } from "react";

export default function Checkout(){
  const { items, total, clear } = useCart();
  const [processing, setProcessing] = useState(false);

  const doFakePayment = async (e) => {
    e.preventDefault();
    setProcessing(true);
    await new Promise(r=>setTimeout(r,1200));
    clear();
    window.location.href = '/order-success';
  }

  if(items.length===0) return <div className="text-gray-300">Your cart is empty</div>

  return (
    <div className="max-w-xl bg-gray-900/60 p-6 rounded-lg border border-gray-700">
      <h2 className="text-2xl font-bold text-white mb-4">Checkout</h2>
      <div className="text-gray-300 mb-4">Total: <span className="text-emerald-400 font-semibold">₹{total}</span></div>
      <form onSubmit={doFakePayment} className="space-y-3">
        <input required placeholder="Name on card" className="w-full p-2 rounded bg-gray-800/60 text-white border border-gray-700"/>
        <input required placeholder="Card number" className="w-full p-2 rounded bg-gray-800/60 text-white border border-gray-700"/>
        <div className="flex gap-2">
          <input required placeholder="MM/YY" className="w-1/3 p-2 rounded bg-gray-800/60 text-white border border-gray-700"/>
          <input required placeholder="CVC" className="w-2/3 p-2 rounded bg-gray-800/60 text-white border border-gray-700"/>
        </div>
        <button type="submit" className="px-4 py-2 bg-emerald-600 rounded text-white">{processing? 'Processing...':'Pay Now'}</button>
      </form>
    </div>
  )
}