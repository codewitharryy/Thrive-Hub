import React, { useEffect, useState } from "react";
import ProductCard from "./ProductCard";
import { useCart } from "../../contexts/CartContext";

export default function Store(){
  const [products, setProducts] = useState([]);
  const { add } = useCart();

  useEffect(()=>{
    fetch('/src/data/products.json').then(r=>r.json()).then(setProducts).catch(e=>console.error(e));
  },[]);

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-white">Thrive Store</h2>
        <p className="text-sm text-gray-300">Mix of fitness gear, meals & wellness</p>
      </header>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map(p=> <ProductCard key={p.id} p={p} onAdd={add} />)}
      </div>
    </div>
  )
}