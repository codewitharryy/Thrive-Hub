import React, { useEffect } from "react";

export default function OrderSuccess(){
  useEffect(()=>{
    const el = document.getElementById('confetti');
    if(!el) return;
    el.innerHTML = '';
    for(let i=0;i<40;i++){
      const s = document.createElement('div');
      s.textContent = ['🎉','✨','💪','🧘'][Math.floor(Math.random()*4)];
      s.style.position='absolute';
      s.style.left = Math.random()*90 + '%';
      s.style.top = Math.random()*20 + '%';
      s.style.fontSize = Math.random()*24+12+'px';
      el.appendChild(s);
      setTimeout(()=> s.remove(), 2500);
    }
  },[]);
  return (
    <div className="p-8 bg-gray-900/60 rounded-lg border border-gray-700 max-w-xl">
      <div id="confetti" className="relative h-20"></div>
      <h2 className="text-2xl text-white font-bold">Order Successful!</h2>
      <p className="text-gray-300 mt-2">Thank you for your order. We will process it soon.</p>
      <div className="mt-4">
        <a href="/" className="px-4 py-2 bg-emerald-600 rounded text-white">Back to Home</a>
      </div>
    </div>
  )
}