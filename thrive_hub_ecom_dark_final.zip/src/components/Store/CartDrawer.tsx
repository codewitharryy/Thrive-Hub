import React from "react";
import { useCart } from "../../contexts/CartContext";

export default function CartDrawer({onCheckout}){
  const { items, remove, updateQty, total, clear } = useCart();
  return (
    <div className="fixed right-6 top-16 w-96 bg-gray-900/90 border border-gray-700 rounded-lg p-4 z-50 shadow-xl">
      <h3 className="text-white font-semibold mb-3">Your Cart</h3>
      <div className="space-y-3 max-h-72 overflow-auto">
        {items.length===0 && <div className="text-gray-400">Cart is empty</div>}
        {items.map(it=> (
          <div key={it.id} className="flex items-center justify-between bg-gray-800/40 p-2 rounded-md">
            <div>
              <div className="text-white">{it.title}</div>
              <div className="text-sm text-gray-400">₹{it.price} × {it.qty}</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={()=>updateQty(it.id, Math.max(1,it.qty-1))} className="px-2 bg-gray-700 rounded">-</button>
              <button onClick={()=>updateQty(it.id, it.qty+1)} className="px-2 bg-gray-700 rounded">+</button>
              <button onClick={()=>remove(it.id)} className="px-2 bg-red-600 rounded">x</button>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-between">
        <div className="text-emerald-400 font-bold">Total: ₹{total}</div>
        <div className="flex items-center gap-2">
          <button onClick={clear} className="px-3 py-1 bg-gray-700 rounded text-sm">Clear</button>
          <button onClick={onCheckout} className="px-3 py-1 bg-emerald-600 rounded text-sm">Checkout</button>
        </div>
      </div>
    </div>
  )
}