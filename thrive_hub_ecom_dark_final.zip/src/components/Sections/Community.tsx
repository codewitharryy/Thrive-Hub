import React, { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { supabase } from '../../lib/supabase'
import { 
  Users, 
  MessageCircle, 
  Heart, 
  UserPlus,
  Search,
  Filter,
  Loader,
  Star
} from 'lucide-react'

export function Community() {
  const { profile, user } = useAuth()
  const [communities, setCommunities] = useState<any[]>([])
  const [joinedCommunities, setJoinedCommunities] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState('all')
  const [joiningCommunity, setJoiningCommunity] = useState<string | null>(null)

  useEffect(() => {
    fetchCommunities()
    fetchUserCommunities()
  }, [])

  const fetchCommunities = async () => {
    try {
      const { data, error } = await supabase
        .from('communities')
        .select('*')
        .eq('is_public', true)
        .order('member_count', { ascending: false })

      if (error) throw error
      setCommunities(data || [])
    } catch (error) {
      console.error('Error fetching communities:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchUserCommunities = async () => {
    if (!user) return

    try {
      const { data, error } = await supabase
        .from('user_communities')
        .select('community_id')
        .eq('user_id', user.id)

      if (error) throw error
      setJoinedCommunities(data?.map(item => item.community_id) || [])
    } catch (error) {
      console.error('Error fetching user communities:', error)
    }
  }

  const joinCommunity = async (communityId: string) => {
    if (!user || joiningCommunity) return

    setJoiningCommunity(communityId)
    
    try {
      const { error } = await supabase
        .from('user_communities')
        .insert({
          user_id: user.id,
          community_id: communityId
        })

      if (error) throw error
      
      setJoinedCommunities(prev => [...prev, communityId])
      
      // Award points for joining community
      await supabase.from('user_points').insert({
        user_id: user.id,
        points: 15,
        source: 'community_join',
        description: 'Joined a community'
      })

      // Update community member count (handled by database trigger)
      await fetchCommunities()
      
    } catch (error) {
      console.error('Error joining community:', error)
    } finally {
      setJoiningCommunity(null)
    }
  }

  const leaveCommunity = async (communityId: string) => {
    if (!user) return

    try {
      const { error } = await supabase
        .from('user_communities')
        .delete()
        .eq('user_id', user.id)
        .eq('community_id', communityId)

      if (error) throw error
      
      setJoinedCommunities(prev => prev.filter(id => id !== communityId))
      await fetchCommunities()
      
    } catch (error) {
      console.error('Error leaving community:', error)
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'students': return '🎓'
      case 'professionals': return '💼'
      case 'fitness': return '💪'
      case 'mental_health': return '🧠'
      case 'nutrition': return '🥗'
      default: return '👥'
    }
  }

  const filteredCommunities = communities.filter(community => {
    const matchesSearch = community.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         community.description?.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesCategory = filterCategory === 'all' || community.category === filterCategory
    
    return matchesSearch && matchesCategory
  })

  const communityStats = {
    total: communities.length,
    joined: joinedCommunities.length,
    members: communities.reduce((sum, c) => sum + c.member_count, 0)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Community Hub
        </h2>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Connect with like-minded individuals on their wellness journey
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 text-center shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 rounded-full w-fit mx-auto mb-3">
            <Users className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-gray-900 dark:text-white">{communityStats.total}</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">Available Communities</div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 text-center shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-full w-fit mx-auto mb-3">
            <Heart className="h-6 w-6 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-gray-900 dark:text-white">{communityStats.joined}</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">Communities Joined</div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 text-center shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-full w-fit mx-auto mb-3">
            <MessageCircle className="h-6 w-6 text-purple-600 dark:text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-gray-900 dark:text-white">{communityStats.members}</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">Total Members</div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search communities..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="pl-10 pr-8 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Categories</option>
              <option value="students">Students</option>
              <option value="professionals">Professionals</option>
              <option value="fitness">Fitness</option>
              <option value="mental_health">Mental Health</option>
              <option value="nutrition">Nutrition</option>
            </select>
          </div>
        </div>
      </div>

      {/* Communities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCommunities.map((community) => {
          const isJoined = joinedCommunities.includes(community.id)
          const isJoining = joiningCommunity === community.id

          return (
            <div
              key={community.id}
              className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="text-2xl">{getCategoryIcon(community.category)}</div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white text-lg">
                      {community.name}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                      {community.category?.replace('_', ' ')}
                    </p>
                  </div>
                </div>
                
                {isJoined && (
                  <div className="flex items-center space-x-1 bg-emerald-100 dark:bg-emerald-900/30 px-2 py-1 rounded-full">
                    <Star className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                      Joined
                    </span>
                  </div>
                )}
              </div>

              <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-3">
                {community.description}
              </p>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                  <Users className="h-4 w-4" />
                  <span>{community.member_count} members</span>
                </div>

                {isJoined ? (
                  <button
                    onClick={() => leaveCommunity(community.id)}
                    className="px-4 py-2 text-sm border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    Leave
                  </button>
                ) : (
                  <button
                    onClick={() => joinCommunity(community.id)}
                    disabled={isJoining}
                    className="px-4 py-2 text-sm bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-1"
                  >
                    {isJoining ? (
                      <Loader className="h-4 w-4 animate-spin" />
                    ) : (
                      <UserPlus className="h-4 w-4" />
                    )}
                    <span>{isJoining ? 'Joining...' : 'Join'}</span>
                  </button>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {filteredCommunities.length === 0 && (
        <div className="text-center py-12">
          <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No communities found
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Try adjusting your search or filter criteria
          </p>
        </div>
      )}
    </div>
  )
}