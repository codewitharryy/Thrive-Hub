import React, { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { supabase } from '../../lib/supabase'
import { 
  Star, 
  TrendingUp, 
  Calendar, 
  Activity,
  Heart,
  Users,
  BookOpen,
  MessageCircle,
  Award,
  Loader
} from 'lucide-react'

export function Points() {
  const { profile, user } = useAuth()
  const [pointsHistory, setPointsHistory] = useState<any[]>([])
  const [activities, setActivities] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [timeFilter, setTimeFilter] = useState('all')

  useEffect(() => {
    if (user) {
      fetchPointsData()
    }
  }, [user, timeFilter])

  const fetchPointsData = async () => {
    if (!user) return
    
    setLoading(true)
    try {
      // Fetch points history
      let pointsQuery = supabase
        .from('user_points')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (timeFilter !== 'all') {
        const date = new Date()
        switch (timeFilter) {
          case 'week':
            date.setDate(date.getDate() - 7)
            break
          case 'month':
            date.setMonth(date.getMonth() - 1)
            break
          case 'year':
            date.setFullYear(date.getFullYear() - 1)
            break
        }
        pointsQuery = pointsQuery.gte('created_at', date.toISOString())
      }

      const { data: pointsData, error: pointsError } = await pointsQuery

      if (pointsError) throw pointsError
      setPointsHistory(pointsData || [])

      // Fetch activities
      const { data: activitiesData, error: activitiesError } = await supabase
        .from('user_activities')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10)

      if (activitiesError) throw activitiesError
      setActivities(activitiesData || [])

    } catch (error) {
      console.error('Error fetching points data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'profile_complete': return <Star className="h-5 w-5 text-yellow-500" />
      case 'community_join': return <Users className="h-5 w-5 text-blue-500" />
      case 'resource_view': return <BookOpen className="h-5 w-5 text-green-500" />
      case 'ai_chat': return <MessageCircle className="h-5 w-5 text-purple-500" />
      case 'workout_log': return <Activity className="h-5 w-5 text-red-500" />
      case 'achievement': return <Award className="h-5 w-5 text-orange-500" />
      default: return <Heart className="h-5 w-5 text-emerald-500" />
    }
  }

  const getSourceName = (source: string) => {
    switch (source) {
      case 'profile_complete': return 'Profile Setup'
      case 'community_join': return 'Community Join'
      case 'resource_view': return 'Resource View'
      case 'ai_chat': return 'AI Chat'
      case 'workout_log': return 'Workout Log'
      case 'achievement': return 'Achievement'
      default: return 'Activity'
    }
  }

  const getTotalPoints = () => {
    return pointsHistory.reduce((sum, point) => sum + point.points, 0)
  }

  const getPointsBreakdown = () => {
    const breakdown: { [key: string]: number } = {}
    pointsHistory.forEach(point => {
      breakdown[point.source] = (breakdown[point.source] || 0) + point.points
    })
    return Object.entries(breakdown).sort((a, b) => b[1] - a[1])
  }

  const pointsBreakdown = getPointsBreakdown()
  const totalFilteredPoints = getTotalPoints()

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Points Earned
        </h2>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Track your wellness journey achievements and rewards
        </p>
      </div>

      {/* Points Summary */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl p-8 text-white">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{profile?.total_points || 0}</div>
            <div className="text-lg opacity-90">Total Points</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{totalFilteredPoints}</div>
            <div className="text-lg opacity-90">
              {timeFilter === 'all' ? 'All Time' : 
               timeFilter === 'week' ? 'This Week' : 
               timeFilter === 'month' ? 'This Month' : 'This Year'}
            </div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">{pointsHistory.length}</div>
            <div className="text-lg opacity-90">Activities</div>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Points History
          </h3>
          <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
            {[
              { key: 'all', label: 'All Time' },
              { key: 'week', label: 'Week' },
              { key: 'month', label: 'Month' },
              { key: 'year', label: 'Year' }
            ].map((filter) => (
              <button
                key={filter.key}
                onClick={() => setTimeFilter(filter.key)}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  timeFilter === filter.key
                    ? 'bg-emerald-600 text-white'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Points Breakdown */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6 flex items-center">
            <TrendingUp className="h-5 w-5 mr-2 text-emerald-600" />
            Points by Category
          </h3>
          
          {pointsBreakdown.length > 0 ? (
            <div className="space-y-4">
              {pointsBreakdown.map(([source, points]) => (
                <div key={source} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getSourceIcon(source)}
                    <span className="font-medium text-gray-900 dark:text-white">
                      {getSourceName(source)}
                    </span>
                  </div>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">
                    {points} pts
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              No points earned in this period
            </div>
          )}
        </div>

        {/* Recent Activities */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6 flex items-center">
            <Activity className="h-5 w-5 mr-2 text-emerald-600" />
            Recent Activities
          </h3>
          
          {activities.length > 0 ? (
            <div className="space-y-3">
              {activities.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white capitalize">
                      {activity.activity_type.replace('_', ' ')}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {new Date(activity.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                    +{activity.points_earned} pts
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              No recent activities
            </div>
          )}
        </div>
      </div>

      {/* Detailed Points History */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6 flex items-center">
          <Calendar className="h-5 w-5 mr-2 text-emerald-600" />
          Detailed History
        </h3>
        
        {pointsHistory.length > 0 ? (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {pointsHistory.map((point) => (
              <div key={point.id} className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                <div className="flex items-center space-x-4">
                  {getSourceIcon(point.source)}
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">
                      {getSourceName(point.source)}
                    </div>
                    {point.description && (
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {point.description}
                      </div>
                    )}
                    <div className="text-xs text-gray-500 dark:text-gray-500">
                      {new Date(point.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>
                <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                  +{point.points}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Star className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              No points yet
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Start engaging with the platform to earn points!
            </p>
          </div>
        )}
      </div>
    </div>
  )
}