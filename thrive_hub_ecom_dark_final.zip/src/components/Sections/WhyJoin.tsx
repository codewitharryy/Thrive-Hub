import React from 'react'
import { 
  Heart, 
  Users, 
  Target, 
  Award, 
  Brain, 
  Activity,
  Star,
  TrendingUp
} from 'lucide-react'

export function WhyJoin() {
  const benefits = [
    {
      icon: Heart,
      title: 'Holistic Wellness Approach',
      description: 'Focus on both physical and mental wellbeing with personalized guidance tailored to your unique needs and goals.',
      color: 'text-red-500',
      bgColor: 'bg-red-100 dark:bg-red-900/20'
    },
    {
      icon: Brain,
      title: 'AI-Powered Personalization',
      description: 'Get intelligent recommendations based on your profile, goals, and progress with our advanced AI wellness coach.',
      color: 'text-purple-500',
      bgColor: 'bg-purple-100 dark:bg-purple-900/20'
    },
    {
      icon: Users,
      title: 'Supportive Community',
      description: 'Connect with like-minded students and professionals who share your wellness journey and challenges.',
      color: 'text-blue-500',
      bgColor: 'bg-blue-100 dark:bg-blue-900/20'
    },
    {
      icon: Target,
      title: 'Goal-Oriented Progress',
      description: 'Set meaningful goals and track your progress with detailed analytics and milestone celebrations.',
      color: 'text-green-500',
      bgColor: 'bg-green-100 dark:bg-green-900/20'
    },
    {
      icon: Award,
      title: 'Gamification & Rewards',
      description: 'Earn points, unlock achievements, and stay motivated with our engaging reward system.',
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-100 dark:bg-yellow-900/20'
    },
    {
      icon: Activity,
      title: 'Expert Trainer Access',
      description: 'Connect with verified fitness professionals for personalized workout plans and guidance.',
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-100 dark:bg-emerald-900/20'
    }
  ]

  const features = [
    {
      title: 'For Students',
      points: [
        'Stress management techniques for academic pressure',
        'Budget-friendly nutrition and fitness solutions',
        'Time-efficient workout routines for busy schedules',
        'Mental health support during challenging periods',
        'Study-life balance optimization'
      ]
    },
    {
      title: 'For Professionals',
      points: [
        'Workplace wellness strategies',
        'Quick desk exercises and posture improvement',
        'Meal prep solutions for busy lifestyles',
        'Work-life balance techniques',
        'Energy management throughout the workday'
      ]
    },
    {
      title: 'For Everyone',
      points: [
        'Personalized workout recommendations',
        'Gender-specific health guidance',
        'BMI-based nutrition suggestions',
        'Sleep optimization strategies',
        'Habit formation support'
      ]
    }
  ]

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Why Join Thrive Hub?
        </h2>
        <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Transform your wellness journey with our comprehensive platform designed specifically 
          for students and professionals seeking sustainable health improvements.
        </p>
      </div>

      {/* Benefits Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {benefits.map((benefit, index) => {
          const Icon = benefit.icon
          return (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200"
            >
              <div className={`p-3 ${benefit.bgColor} rounded-lg w-fit mb-4`}>
                <Icon className={`h-6 w-6 ${benefit.color}`} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                {benefit.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">
                {benefit.description}
              </p>
            </div>
          )
        })}
      </div>

      {/* Features for Different Users */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => (
          <div
            key={index}
            className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-gray-800 dark:to-gray-700 rounded-xl p-6 border border-emerald-200 dark:border-gray-600"
          >
            <h3 className="text-xl font-bold text-emerald-700 dark:text-emerald-300 mb-4">
              {feature.title}
            </h3>
            <ul className="space-y-2">
              {feature.points.map((point, pointIndex) => (
                <li key={pointIndex} className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-sm text-gray-700 dark:text-gray-300">{point}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Success Metrics */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white text-center mb-8">
          Join Thousands Who've Transformed Their Lives
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <TrendingUp className="h-6 w-6 text-emerald-600 mr-2" />
              <span className="text-3xl font-bold text-emerald-600">89%</span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Improved overall wellness within 30 days
            </p>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Users className="h-6 w-6 text-blue-600 mr-2" />
              <span className="text-3xl font-bold text-blue-600">10K+</span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Active community members
            </p>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Star className="h-6 w-6 text-yellow-600 mr-2" />
              <span className="text-3xl font-bold text-yellow-600">4.8</span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Average user satisfaction rating
            </p>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Activity className="h-6 w-6 text-purple-600 mr-2" />
              <span className="text-3xl font-bold text-purple-600">76%</span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Achieve their fitness goals
            </p>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl p-8 text-white text-center">
        <h3 className="text-2xl font-bold mb-4">Ready to Start Your Journey?</h3>
        <p className="text-lg opacity-90 mb-6">
          Join our community today and take the first step towards a healthier, happier you.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="px-8 py-3 bg-white text-emerald-600 font-semibold rounded-lg hover:bg-gray-100 transition-colors">
            Complete Your Profile
          </button>
          <button className="px-8 py-3 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-emerald-600 transition-colors">
            Explore Community
          </button>
        </div>
      </div>
    </div>
  )
}