import React, { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { supabase } from '../../lib/supabase'
import { 
  BookOpen, 
  Play, 
  Clock, 
  Eye,
  Search,
  Filter,
  Loader,
  Heart,
  Dumbbell,
  Brain
} from 'lucide-react'

export function Resources() {
  const { profile, user } = useAuth()
  const [resources, setResources] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterType, setFilterType] = useState('all')
  const [filterGender, setFilterGender] = useState('all')

  useEffect(() => {
    fetchResources()
  }, [])

  const fetchResources = async () => {
    try {
      const { data, error } = await supabase
        .from('resources')
        .select('*')
        .eq('is_published', true)
        .order('created_at', { ascending: false })

      if (error) throw error
      setResources(data || [])
    } catch (error) {
      console.error('Error fetching resources:', error)
    } finally {
      setLoading(false)
    }
  }

  const incrementViewCount = async (resourceId: string) => {
    try {
      await supabase
        .from('resources')
        .update({ view_count: resources.find(r => r.id === resourceId)?.view_count + 1 })
        .eq('id', resourceId)

      // Award points for reading resource
      if (user) {
        await supabase.from('user_points').insert({
          user_id: user.id,
          points: 3,
          source: 'resource_view',
          description: 'Viewed a wellness resource'
        })
      }

      // Update local state
      setResources(prev => prev.map(r => 
        r.id === resourceId ? { ...r, view_count: r.view_count + 1 } : r
      ))
    } catch (error) {
      console.error('Error incrementing view count:', error)
    }
  }

  const getResourceIcon = (type: string) => {
    switch (type) {
      case 'article': return BookOpen
      case 'video': return Play
      case 'workout': return Dumbbell
      case 'blog': return BookOpen
      case 'recipe': return Heart
      default: return BookOpen
    }
  }

  const getResourceColor = (type: string) => {
    switch (type) {
      case 'article': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/30'
      case 'video': return 'text-red-600 bg-red-100 dark:bg-red-900/30'
      case 'workout': return 'text-emerald-600 bg-emerald-100 dark:bg-emerald-900/30'
      case 'blog': return 'text-purple-600 bg-purple-100 dark:bg-purple-900/30'
      case 'recipe': return 'text-orange-600 bg-orange-100 dark:bg-orange-900/30'
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/30'
    }
  }

  const getDifficultyColor = (level: string) => {
    switch (level) {
      case 'beginner': return 'text-green-600 bg-green-100 dark:bg-green-900/20'
      case 'intermediate': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20'
      case 'advanced': return 'text-red-600 bg-red-100 dark:bg-red-900/20'
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20'
    }
  }

  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.content?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.tags?.some((tag: string) => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    
    const matchesType = filterType === 'all' || resource.type === filterType
    
    const matchesGender = filterGender === 'all' || 
                         resource.target_gender === 'all' || 
                         resource.target_gender === filterGender ||
                         (filterGender === profile?.gender && (resource.target_gender === profile.gender || resource.target_gender === 'all'))
    
    return matchesSearch && matchesType && matchesGender
  })

  // Get personalized recommendations
  const getPersonalizedResources = () => {
    const userGender = profile?.gender
    const userGoal = profile?.fitness_goal
    const userBMI = profile?.bmi

    return resources.filter(resource => {
      // Gender-specific content
      if (userGender && resource.target_gender === userGender) return true
      
      // Goal-related content
      if (userGoal && resource.tags?.includes(userGoal)) return true
      
      // BMI-based recommendations
      if (userBMI) {
        if (userBMI < 18.5 && resource.tags?.includes('weight_gain')) return true
        if (userBMI > 25 && resource.tags?.includes('weight_loss')) return true
      }
      
      // General wellness content
      if (resource.target_gender === 'all') return true
      
      return false
    }).slice(0, 6)
  }

  const personalizedResources = getPersonalizedResources()

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Wellness Resources
        </h2>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Expert-curated content to support your wellness journey
        </p>
      </div>

      {/* Personalized Recommendations */}
      {personalizedResources.length > 0 && (
        <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-gray-800 dark:to-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
            <Brain className="h-5 w-5 mr-2 text-emerald-600" />
            Recommended for You
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {personalizedResources.slice(0, 3).map((resource) => {
              const Icon = getResourceIcon(resource.type)
              const colorClass = getResourceColor(resource.type)
              
              return (
                <div
                  key={resource.id}
                  className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => incrementViewCount(resource.id)}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-lg ${colorClass}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 dark:text-white text-sm line-clamp-2">
                        {resource.title}
                      </h4>
                      <div className="flex items-center space-x-2 text-xs text-gray-600 dark:text-gray-400 mt-1">
                        <Clock className="h-3 w-3" />
                        <span>{resource.duration_minutes || 5} min</span>
                        <Eye className="h-3 w-3" />
                        <span>{resource.view_count}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Search and Filter */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search resources..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          
          <div className="flex gap-2">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Types</option>
              <option value="article">Articles</option>
              <option value="video">Videos</option>
              <option value="workout">Workouts</option>
              <option value="blog">Blogs</option>
              <option value="recipe">Recipes</option>
            </select>

            <select
              value={filterGender}
              onChange={(e) => setFilterGender(e.target.value)}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Content</option>
              <option value="male">Male-Focused</option>
              <option value="female">Female-Focused</option>
            </select>
          </div>
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map((resource) => {
          const Icon = getResourceIcon(resource.type)
          const colorClass = getResourceColor(resource.type)
          const difficultyClass = getDifficultyColor(resource.difficulty_level)
          
          return (
            <div
              key={resource.id}
              className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200 cursor-pointer"
              onClick={() => incrementViewCount(resource.id)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-lg ${colorClass}`}>
                  <Icon className="h-6 w-6" />
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${difficultyClass}`}>
                    {resource.difficulty_level}
                  </span>
                  {resource.target_gender !== 'all' && (
                    <span className="px-2 py-1 text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full">
                      {resource.target_gender}
                    </span>
                  )}
                </div>
              </div>

              <h3 className="font-semibold text-gray-900 dark:text-white text-lg mb-2 line-clamp-2">
                {resource.title}
              </h3>
              
              <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-3">
                {resource.content}
              </p>

              <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{resource.duration_minutes || 5} min</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="h-4 w-4" />
                    <span>{resource.view_count}</span>
                  </div>
                </div>
                
                <div className="text-xs capitalize">
                  {resource.category}
                </div>
              </div>

              {resource.tags && resource.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-3">
                  {resource.tags.slice(0, 3).map((tag: string, index: number) => (
                    <span
                      key={index}
                      className="px-2 py-1 text-xs bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 rounded-full"
                    >
                      {tag.replace('_', ' ')}
                    </span>
                  ))}
                  {resource.tags.length > 3 && (
                    <span className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full">
                      +{resource.tags.length - 3}
                    </span>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {filteredResources.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No resources found
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Try adjusting your search or filter criteria
          </p>
        </div>
      )}
    </div>
  )
}