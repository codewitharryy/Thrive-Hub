import React, { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { supabase } from '../../lib/supabase'
import { 
  Trophy, 
  Medal, 
  Star, 
  Crown,
  TrendingUp,
  Calendar,
  Loader,
  Award
} from 'lucide-react'

export function Scoreboard() {
  const { profile, user } = useAuth()
  const [leaderboard, setLeaderboard] = useState<any[]>([])
  const [userRank, setUserRank] = useState<number | null>(null)
  const [timeframe, setTimeframe] = useState<'weekly' | 'monthly' | 'all-time'>('weekly')
  const [loading, setLoading] = useState(true)
  const [achievements, setAchievements] = useState<any[]>([])

  useEffect(() => {
    fetchLeaderboard()
    fetchAchievements()
  }, [timeframe])

  const fetchLeaderboard = async () => {
    setLoading(true)
    try {
      let query = supabase
        .from('user_profiles')
        .select('id, full_name, total_points, profession, created_at')
        .order('total_points', { ascending: false })
        .limit(50)

      const { data, error } = await query
      if (error) throw error

      const rankedData = data?.map((user, index) => ({
        ...user,
        rank: index + 1
      })) || []

      setLeaderboard(rankedData)
      
      // Find current user's rank
      if (user) {
        const currentUserRank = rankedData.findIndex(u => u.id === user.id)
        setUserRank(currentUserRank >= 0 ? currentUserRank + 1 : null)
      }
    } catch (error) {
      console.error('Error fetching leaderboard:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchAchievements = async () => {
    try {
      // Mock achievements - in a real app, these would come from the database
      const mockAchievements = [
        {
          id: 1,
          title: 'First Steps',
          description: 'Complete your profile setup',
          icon: '🎯',
          unlocked: profile?.profile_completed,
          points: 50
        },
        {
          id: 2,
          title: 'Community Builder',
          description: 'Join your first community',
          icon: '👥',
          unlocked: true, // Would check user_communities
          points: 100
        },
        {
          id: 3,
          title: 'Knowledge Seeker',
          description: 'Read 5 wellness articles',
          icon: '📚',
          unlocked: false,
          points: 75
        },
        {
          id: 4,
          title: 'Conversation Starter',
          description: 'Chat with AI coach 10 times',
          icon: '💬',
          unlocked: true,
          points: 150
        },
        {
          id: 5,
          title: 'Wellness Warrior',
          description: 'Reach 500 total points',
          icon: '⚡',
          unlocked: (profile?.total_points || 0) >= 500,
          points: 200
        },
        {
          id: 6,
          title: 'Streak Master',
          description: 'Maintain a 7-day activity streak',
          icon: '🔥',
          unlocked: false,
          points: 300
        }
      ]

      setAchievements(mockAchievements)
    } catch (error) {
      console.error('Error fetching achievements:', error)
    }
  }

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-6 w-6 text-yellow-500" />
      case 2: return <Medal className="h-6 w-6 text-gray-400" />
      case 3: return <Medal className="h-6 w-6 text-orange-400" />
      default: return <span className="text-lg font-bold text-gray-600 dark:text-gray-400">#{rank}</span>
    }
  }

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-gradient-to-r from-yellow-400 to-yellow-600'
      case 2: return 'bg-gradient-to-r from-gray-400 to-gray-600'
      case 3: return 'bg-gradient-to-r from-orange-400 to-orange-600'
      default: return 'bg-white dark:bg-gray-800'
    }
  }

  const getTimeframeDates = () => {
    const now = new Date()
    switch (timeframe) {
      case 'weekly':
        const weekStart = new Date(now.setDate(now.getDate() - now.getDay()))
        return `Week of ${weekStart.toLocaleDateString()}`
      case 'monthly':
        return `${now.toLocaleString('default', { month: 'long' })} ${now.getFullYear()}`
      case 'all-time':
        return 'All Time'
      default:
        return ''
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Wellness Scoreboard
        </h2>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Celebrate achievements and track your progress
        </p>
      </div>

      {/* User Stats */}
      {profile && (
        <div className="bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl p-6 text-white">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold mb-1">{profile.total_points || 0}</div>
              <div className="text-sm opacity-90">Total Points</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold mb-1">#{userRank || '?'}</div>
              <div className="text-sm opacity-90">Global Rank</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold mb-1">{achievements.filter(a => a.unlocked).length}</div>
              <div className="text-sm opacity-90">Achievements</div>
            </div>
          </div>
        </div>
      )}

      {/* Timeframe Selector */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Leaderboard - {getTimeframeDates()}
          </h3>
          
          <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
            {(['weekly', 'monthly', 'all-time'] as const).map((period) => (
              <button
                key={period}
                onClick={() => setTimeframe(period)}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  timeframe === period
                    ? 'bg-emerald-600 text-white'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                {period === 'all-time' ? 'All Time' : period.charAt(0).toUpperCase() + period.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Top 3 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {leaderboard.slice(0, 3).map((user, index) => {
            const rank = index + 1
            const isCurrentUser = user.id === profile?.id
            
            return (
              <div
                key={user.id}
                className={`${getRankBg(rank)} ${
                  rank <= 3 ? 'text-white' : 'border border-gray-200 dark:border-gray-700'
                } rounded-lg p-4 text-center ${isCurrentUser ? 'ring-2 ring-emerald-400' : ''}`}
              >
                <div className="flex justify-center mb-2">
                  {getRankIcon(rank)}
                </div>
                <div className="font-semibold mb-1">
                  {user.full_name || 'Anonymous'}
                  {isCurrentUser && ' (You)'}
                </div>
                <div className="text-sm opacity-75 mb-2">
                  {user.profession || 'Member'}
                </div>
                <div className="text-2xl font-bold">
                  {user.total_points} pts
                </div>
              </div>
            )
          })}
        </div>

        {/* Rest of leaderboard */}
        <div className="space-y-2">
          {leaderboard.slice(3, 20).map((user) => {
            const isCurrentUser = user.id === profile?.id
            
            return (
              <div
                key={user.id}
                className={`flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg ${
                  isCurrentUser ? 'ring-2 ring-emerald-400' : ''
                }`}
              >
                <div className="flex items-center space-x-4">
                  <div className="w-8 text-center">
                    <span className="text-lg font-bold text-gray-600 dark:text-gray-400">
                      #{user.rank}
                    </span>
                  </div>
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">
                      {user.full_name || 'Anonymous'}
                      {isCurrentUser && <span className="text-emerald-600 ml-1">(You)</span>}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {user.profession || 'Member'}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span className="font-bold text-gray-900 dark:text-white">
                    {user.total_points}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6 flex items-center">
          <Award className="h-5 w-5 mr-2 text-emerald-600" />
          Achievements
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievements.map((achievement) => (
            <div
              key={achievement.id}
              className={`p-4 rounded-lg border-2 transition-all ${
                achievement.unlocked
                  ? 'border-emerald-200 bg-emerald-50 dark:bg-emerald-900/20 dark:border-emerald-800'
                  : 'border-gray-200 bg-gray-50 dark:bg-gray-700 dark:border-gray-600 opacity-60'
              }`}
            >
              <div className="flex items-start space-x-3">
                <div className="text-2xl">{achievement.icon}</div>
                <div className="flex-1">
                  <h4 className={`font-semibold mb-1 ${
                    achievement.unlocked 
                      ? 'text-emerald-800 dark:text-emerald-200' 
                      : 'text-gray-600 dark:text-gray-400'
                  }`}>
                    {achievement.title}
                  </h4>
                  <p className={`text-sm mb-2 ${
                    achievement.unlocked 
                      ? 'text-emerald-600 dark:text-emerald-300' 
                      : 'text-gray-500 dark:text-gray-500'
                  }`}>
                    {achievement.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-medium ${
                      achievement.unlocked 
                        ? 'text-emerald-700 dark:text-emerald-300' 
                        : 'text-gray-500 dark:text-gray-500'
                    }`}>
                      {achievement.points} points
                    </span>
                    {achievement.unlocked && (
                      <div className="flex items-center space-x-1 text-emerald-600 dark:text-emerald-400">
                        <Trophy className="h-3 w-3" />
                        <span className="text-xs font-medium">Unlocked</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}