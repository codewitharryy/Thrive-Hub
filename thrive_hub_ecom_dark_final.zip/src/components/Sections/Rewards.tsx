import React, { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { supabase } from '../../lib/supabase'
import { 
  Gift, 
  Star, 
  Trophy, 
  Crown,
  Zap,
  Heart,
  Target,
  Award,
  ShoppingBag,
  Dumbbell,
  Book,
  Coffee,
  Smartphone,
  Headphones,
  Watch,
  Loader
} from 'lucide-react'

export function Rewards() {
  const { profile, user } = useAuth()
  const [rewards, setRewards] = useState<any[]>([])
  const [userRewards, setUserRewards] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [redeemingReward, setRedeemingReward] = useState<string | null>(null)

  useEffect(() => {
    fetchRewards()
    fetchUserRewards()
  }, [])

  const fetchRewards = async () => {
    // Mock rewards data - in a real app, this would come from the database
    const mockRewards = [
      {
        id: '1',
        title: 'Premium Gym Membership',
        description: '1-month access to premium fitness centers nationwide',
        points_required: 1000,
        category: 'fitness',
        icon: 'dumbbell',
        image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=400',
        value: '$50',
        available: true,
        expires_at: '2024-12-31'
      },
      {
        id: '2',
        title: 'Wellness Book Collection',
        description: 'Digital access to top 10 wellness and fitness books',
        points_required: 500,
        category: 'education',
        icon: 'book',
        image: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
        value: '$30',
        available: true,
        expires_at: '2024-12-31'
      },
      {
        id: '3',
        title: 'Healthy Meal Kit',
        description: 'Week supply of organic, pre-planned healthy meals',
        points_required: 750,
        category: 'nutrition',
        icon: 'heart',
        image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400',
        value: '$40',
        available: true,
        expires_at: '2024-12-31'
      },
      {
        id: '4',
        title: 'Fitness Tracker Watch',
        description: 'Smart fitness watch with heart rate monitoring',
        points_required: 2000,
        category: 'technology',
        icon: 'watch',
        image: 'https://images.pexels.com/photos/393047/pexels-photo-393047.jpeg?auto=compress&cs=tinysrgb&w=400',
        value: '$120',
        available: true,
        expires_at: '2024-12-31'
      },
      {
        id: '5',
        title: 'Meditation App Premium',
        description: '6-month premium subscription to top meditation apps',
        points_required: 600,
        category: 'mental_health',
        icon: 'zap',
        image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=400',
        value: '$35',
        available: true,
        expires_at: '2024-12-31'
      },
      {
        id: '6',
        title: 'Wireless Earbuds',
        description: 'Premium wireless earbuds perfect for workouts',
        points_required: 1500,
        category: 'technology',
        icon: 'headphones',
        image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400',
        value: '$80',
        available: true,
        expires_at: '2024-12-31'
      },
      {
        id: '7',
        title: 'Coffee Shop Voucher',
        description: '$25 voucher for healthy smoothies and organic coffee',
        points_required: 300,
        category: 'lifestyle',
        icon: 'coffee',
        image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400',
        value: '$25',
        available: true,
        expires_at: '2024-12-31'
      },
      {
        id: '8',
        title: 'Personal Training Session',
        description: '1-hour session with certified personal trainer',
        points_required: 800,
        category: 'fitness',
        icon: 'target',
        image: 'https://images.pexels.com/photos/1552106/pexels-photo-1552106.jpeg?auto=compress&cs=tinysrgb&w=400',
        value: '$60',
        available: true,
        expires_at: '2024-12-31'
      }
    ]

    setRewards(mockRewards)
    setLoading(false)
  }

  const fetchUserRewards = async () => {
    if (!user) return

    try {
      // In a real app, fetch user's redeemed rewards from database
      setUserRewards([])
    } catch (error) {
      console.error('Error fetching user rewards:', error)
    }
  }

  const getRewardIcon = (iconName: string) => {
    switch (iconName) {
      case 'dumbbell': return Dumbbell
      case 'book': return Book
      case 'heart': return Heart
      case 'watch': return Watch
      case 'zap': return Zap
      case 'headphones': return Headphones
      case 'coffee': return Coffee
      case 'target': return Target
      default: return Gift
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'fitness': return 'text-red-600 bg-red-100 dark:bg-red-900/30'
      case 'nutrition': return 'text-green-600 bg-green-100 dark:bg-green-900/30'
      case 'mental_health': return 'text-purple-600 bg-purple-100 dark:bg-purple-900/30'
      case 'technology': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/30'
      case 'education': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/30'
      case 'lifestyle': return 'text-pink-600 bg-pink-100 dark:bg-pink-900/30'
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/30'
    }
  }

  const redeemReward = async (rewardId: string, pointsRequired: number) => {
    if (!user || !profile) return

    if (profile.total_points < pointsRequired) {
      alert('Insufficient points to redeem this reward!')
      return
    }

    setRedeemingReward(rewardId)

    try {
      // Deduct points
      await supabase.from('user_points').insert({
        user_id: user.id,
        points: -pointsRequired,
        source: 'reward_redemption',
        description: `Redeemed reward: ${rewards.find(r => r.id === rewardId)?.title}`
      })

      // In a real app, you would also create a user_rewards record
      alert('Reward redeemed successfully! Check your email for details.')
      
    } catch (error) {
      console.error('Error redeeming reward:', error)
      alert('Error redeeming reward. Please try again.')
    } finally {
      setRedeemingReward(null)
    }
  }

  const filteredRewards = rewards.filter(reward => 
    selectedCategory === 'all' || reward.category === selectedCategory
  )

  const userPoints = profile?.total_points || 0

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
          Rewards Store
        </h2>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Redeem your wellness points for amazing rewards and exclusive benefits
        </p>
      </div>

      {/* Points Balance */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl p-8 text-white text-center">
        <div className="flex items-center justify-center mb-4">
          <Crown className="h-12 w-12 text-yellow-300 mr-4" />
          <div>
            <h3 className="text-3xl font-bold">{userPoints}</h3>
            <p className="text-lg opacity-90">Available Points</p>
          </div>
        </div>
        <p className="text-emerald-100">
          Keep earning points through activities, challenges, and engagement to unlock more rewards!
        </p>
      </div>

      {/* Category Filter */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex flex-wrap gap-2">
          {[
            { key: 'all', label: 'All Rewards' },
            { key: 'fitness', label: 'Fitness' },
            { key: 'nutrition', label: 'Nutrition' },
            { key: 'mental_health', label: 'Mental Health' },
            { key: 'technology', label: 'Technology' },
            { key: 'education', label: 'Education' },
            { key: 'lifestyle', label: 'Lifestyle' }
          ].map((category) => (
            <button
              key={category.key}
              onClick={() => setSelectedCategory(category.key)}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                selectedCategory === category.key
                  ? 'bg-emerald-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>
      </div>

      {/* Rewards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredRewards.map((reward) => {
          const Icon = getRewardIcon(reward.icon)
          const categoryColor = getCategoryColor(reward.category)
          const canAfford = userPoints >= reward.points_required
          const isRedeeming = redeemingReward === reward.id

          return (
            <div
              key={reward.id}
              className={`bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 ${
                canAfford ? 'hover:scale-105' : 'opacity-75'
              }`}
            >
              {/* Reward Image */}
              <div className="relative h-48 bg-gray-200 dark:bg-gray-700">
                <img
                  src={reward.image}
                  alt={reward.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 right-3">
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${categoryColor}`}>
                    {reward.category.replace('_', ' ')}
                  </div>
                </div>
                <div className="absolute top-3 left-3">
                  <div className="bg-white dark:bg-gray-800 p-2 rounded-full shadow-sm">
                    <Icon className="h-4 w-4 text-emerald-600" />
                  </div>
                </div>
              </div>

              {/* Reward Content */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white line-clamp-2">
                    {reward.title}
                  </h3>
                  <span className="text-sm font-medium text-emerald-600 dark:text-emerald-400 ml-2">
                    {reward.value}
                  </span>
                </div>

                <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-2">
                  {reward.description}
                </p>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {reward.points_required} points
                    </span>
                  </div>
                  
                  {canAfford ? (
                    <span className="text-xs text-green-600 dark:text-green-400 font-medium">
                      Available
                    </span>
                  ) : (
                    <span className="text-xs text-red-600 dark:text-red-400 font-medium">
                      Need {reward.points_required - userPoints} more
                    </span>
                  )}
                </div>

                <button
                  onClick={() => redeemReward(reward.id, reward.points_required)}
                  disabled={!canAfford || isRedeeming}
                  className={`w-full px-4 py-2 font-medium rounded-lg transition-colors flex items-center justify-center ${
                    canAfford
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                      : 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                  }`}
                >
                  {isRedeeming ? (
                    <Loader className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <ShoppingBag className="h-4 w-4 mr-2" />
                      {canAfford ? 'Redeem Now' : 'Insufficient Points'}
                    </>
                  )}
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {/* Points Earning Tips */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-blue-800 dark:text-blue-200 mb-4 flex items-center">
          <Trophy className="h-5 w-5 mr-2" />
          How to Earn More Points
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl mb-2">💬</div>
            <div className="text-sm font-medium text-blue-800 dark:text-blue-200">AI Chat</div>
            <div className="text-xs text-blue-600 dark:text-blue-400">2 points per interaction</div>
          </div>
          <div className="text-center">
            <div className="text-2xl mb-2">👥</div>
            <div className="text-sm font-medium text-blue-800 dark:text-blue-200">Join Community</div>
            <div className="text-xs text-blue-600 dark:text-blue-400">15 points per community</div>
          </div>
          <div className="text-center">
            <div className="text-2xl mb-2">📚</div>
            <div className="text-sm font-medium text-blue-800 dark:text-blue-200">Read Resources</div>
            <div className="text-xs text-blue-600 dark:text-blue-400">3 points per article</div>
          </div>
          <div className="text-center">
            <div className="text-2xl mb-2">🏋️</div>
            <div className="text-sm font-medium text-blue-800 dark:text-blue-200">Book Trainer</div>
            <div className="text-xs text-blue-600 dark:text-blue-400">25 points per booking</div>
          </div>
        </div>
      </div>
    </div>
  )
}