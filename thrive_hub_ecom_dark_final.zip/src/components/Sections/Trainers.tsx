import React, { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { supabase } from '../../lib/supabase'
import { 
  UserCheck, 
  Star, 
  Clock, 
  DollarSign,
  MessageCircle,
  Calendar,
  Award,
  Filter,
  Search,
  Loader,
  Heart,
  Brain,
  Dumbbell,
  Users
} from 'lucide-react'

export function Trainers() {
  const { user } = useAuth()
  const [trainers, setTrainers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterSpecialization, setFilterSpecialization] = useState('all')
  const [selectedTrainer, setSelectedTrainer] = useState<any>(null)
  const [bookingModal, setBookingModal] = useState(false)

  useEffect(() => {
    fetchTrainers()
  }, [])

  const fetchTrainers = async () => {
    try {
      const { data, error } = await supabase
        .from('trainers')
        .select(`
          *,
          user_profiles!trainers_user_id_fkey(full_name, location)
        `)
        .eq('is_verified', true)
        .order('rating', { ascending: false })

      if (error) throw error
      setTrainers(data || [])
    } catch (error) {
      console.error('Error fetching trainers:', error)
    } finally {
      setLoading(false)
    }
  }

  const getSpecializationIcon = (spec: string) => {
    switch (spec.toLowerCase()) {
      case 'fitness': return Dumbbell
      case 'nutrition': return Heart
      case 'mental_health': return Brain
      case 'yoga': return Users
      default: return UserCheck
    }
  }

  const getSpecializationColor = (spec: string) => {
    switch (spec.toLowerCase()) {
      case 'fitness': return 'text-red-600 bg-red-100 dark:bg-red-900/30'
      case 'nutrition': return 'text-green-600 bg-green-100 dark:bg-green-900/30'
      case 'mental_health': return 'text-purple-600 bg-purple-100 dark:bg-purple-900/30'
      case 'yoga': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/30'
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/30'
    }
  }

  const bookSession = async (trainerId: string) => {
    if (!user) return

    try {
      const { error } = await supabase
        .from('trainer_sessions')
        .insert({
          trainer_id: trainerId,
          client_id: user.id,
          title: 'Wellness Consultation',
          description: 'Initial consultation session',
          session_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Tomorrow
          duration_minutes: 60,
          price: selectedTrainer?.hourly_rate || 50,
          status: 'scheduled'
        })

      if (error) throw error

      // Award points for booking session
      await supabase.from('user_points').insert({
        user_id: user.id,
        points: 25,
        source: 'trainer_booking',
        description: 'Booked a trainer session'
      })

      setBookingModal(false)
      alert('Session booked successfully!')
    } catch (error) {
      console.error('Error booking session:', error)
      alert('Error booking session. Please try again.')
    }
  }

  const filteredTrainers = trainers.filter(trainer => {
    const matchesSearch = trainer.user_profiles?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         trainer.bio?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         trainer.specialization?.some((spec: string) => spec.toLowerCase().includes(searchTerm.toLowerCase()))
    
    const matchesSpecialization = filterSpecialization === 'all' || 
                                 trainer.specialization?.includes(filterSpecialization)
    
    return matchesSearch && matchesSpecialization
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
          Professional Trainers & Wellness Experts
        </h2>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Connect with certified professionals who can guide you on your wellness journey with personalized plans and expert advice.
        </p>
      </div>

      {/* Search and Filter */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search trainers by name, specialization, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <select
              value={filterSpecialization}
              onChange={(e) => setFilterSpecialization(e.target.value)}
              className="pl-10 pr-8 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">All Specializations</option>
              <option value="fitness">Fitness Training</option>
              <option value="nutrition">Nutrition</option>
              <option value="mental_health">Mental Health</option>
              <option value="yoga">Yoga & Mindfulness</option>
              <option value="weight_loss">Weight Management</option>
              <option value="strength">Strength Training</option>
            </select>
          </div>
        </div>
      </div>

      {/* Trainers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredTrainers.map((trainer) => (
          <div
            key={trainer.id}
            className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 hover:scale-105"
          >
            {/* Trainer Header */}
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full flex items-center justify-center">
                <span className="text-xl font-bold text-white">
                  {trainer.user_profiles?.full_name?.charAt(0) || 'T'}
                </span>
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  {trainer.user_profiles?.full_name || 'Professional Trainer'}
                </h3>
                <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span>{trainer.rating}/5.0</span>
                  <span>•</span>
                  <span>{trainer.total_sessions} sessions</span>
                </div>
              </div>
              <div className="flex items-center space-x-1 bg-emerald-100 dark:bg-emerald-900/30 px-2 py-1 rounded-full">
                <Award className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
                <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                  Verified
                </span>
              </div>
            </div>

            {/* Specializations */}
            <div className="flex flex-wrap gap-2 mb-4">
              {trainer.specialization?.slice(0, 3).map((spec: string, index: number) => {
                const Icon = getSpecializationIcon(spec)
                const colorClass = getSpecializationColor(spec)
                return (
                  <div key={index} className={`flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium ${colorClass}`}>
                    <Icon className="h-3 w-3" />
                    <span>{spec.replace('_', ' ')}</span>
                  </div>
                )
              })}
              {trainer.specialization?.length > 3 && (
                <span className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full text-xs font-medium">
                  +{trainer.specialization.length - 3} more
                </span>
              )}
            </div>

            {/* Bio */}
            <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-3">
              {trainer.bio || 'Experienced wellness professional dedicated to helping you achieve your health and fitness goals.'}
            </p>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-gray-400" />
                <span className="text-gray-600 dark:text-gray-400">
                  {trainer.experience_years || 5}+ years exp.
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <DollarSign className="h-4 w-4 text-gray-400" />
                <span className="text-gray-600 dark:text-gray-400">
                  ${trainer.hourly_rate || 50}/hour
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex space-x-2">
              <button
                onClick={() => {
                  setSelectedTrainer(trainer)
                  setBookingModal(true)
                }}
                className="flex-1 px-4 py-2 bg-emerald-600 text-white font-medium rounded-lg hover:bg-emerald-700 transition-colors flex items-center justify-center"
              >
                <Calendar className="h-4 w-4 mr-2" />
                Book Session
              </button>
              <button className="px-4 py-2 border border-emerald-600 text-emerald-600 font-medium rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors">
                <MessageCircle className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredTrainers.length === 0 && (
        <div className="text-center py-12">
          <UserCheck className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No trainers found
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Try adjusting your search or filter criteria
          </p>
        </div>
      )}

      {/* Booking Modal */}
      {bookingModal && selectedTrainer && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md p-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Book Session with {selectedTrainer.user_profiles?.full_name}
            </h3>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Duration:</span>
                <span className="font-medium text-gray-900 dark:text-white">60 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Rate:</span>
                <span className="font-medium text-gray-900 dark:text-white">${selectedTrainer.hourly_rate}/hour</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Session Type:</span>
                <span className="font-medium text-gray-900 dark:text-white">Initial Consultation</span>
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => bookSession(selectedTrainer.id)}
                className="flex-1 px-4 py-2 bg-emerald-600 text-white font-medium rounded-lg hover:bg-emerald-700 transition-colors"
              >
                Confirm Booking
              </button>
              <button
                onClick={() => setBookingModal(false)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-medium rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}