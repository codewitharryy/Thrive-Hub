import React from 'react'
import { 
  Heart, 
  Users, 
  Target, 
  Brain,
  Shield,
  Zap,
  Award,
  Globe
} from 'lucide-react'

export function About() {
  const values = [
    {
      icon: Heart,
      title: 'Holistic Wellness',
      description: 'We believe in addressing both physical and mental wellbeing for complete health transformation.'
    },
    {
      icon: Users,
      title: 'Community First',
      description: 'Building supportive connections that encourage and motivate each person on their unique journey.'
    },
    {
      icon: Brain,
      title: 'Evidence-Based',
      description: 'All our recommendations are backed by scientific research and proven wellness methodologies.'
    },
    {
      icon: Shield,
      title: 'Privacy & Security',
      description: 'Your personal health data is protected with enterprise-grade security and privacy measures.'
    }
  ]

  const team = [
    {
      name: 'Dr. Sarah Chen',
      role: 'Chief Wellness Officer',
      expertise: 'Nutritional Psychology, Behavioral Change',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Marcus Rodriguez',
      role: 'Lead Fitness Specialist',
      expertise: 'Exercise Science, Rehabilitation',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Dr. Aisha Patel',
      role: 'Mental Health Director',
      expertise: 'Clinical Psychology, Stress Management',
      image: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'James Kim',
      role: 'Technology Lead',
      expertise: 'AI/ML, Health Analytics',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ]

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="text-center">
        <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">
          About Thrive Hub
        </h2>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto leading-relaxed">
          We're on a mission to revolutionize wellness for students and professionals by creating 
          a comprehensive platform that makes healthy living accessible, personalized, and sustainable.
        </p>
      </div>

      {/* Mission Statement */}
      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-gray-800 dark:to-gray-700 rounded-2xl p-8 lg:p-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
              Our Mission
            </h3>
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
              To empower individuals with the tools, knowledge, and community support they need 
              to achieve sustainable wellness while balancing the demands of academic and professional life.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-emerald-600" />
                <span className="font-medium text-gray-900 dark:text-white">AI-Powered</span>
              </div>
              <div className="flex items-center space-x-2">
                <Globe className="h-5 w-5 text-emerald-600" />
                <span className="font-medium text-gray-900 dark:text-white">Global Community</span>
              </div>
              <div className="flex items-center space-x-2">
                <Award className="h-5 w-5 text-emerald-600" />
                <span className="font-medium text-gray-900 dark:text-white">Expert-Backed</span>
              </div>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/3768916/pexels-photo-3768916.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Wellness journey"
              className="rounded-xl shadow-lg"
            />
            <div className="absolute inset-0 bg-emerald-600 bg-opacity-10 rounded-xl"></div>
          </div>
        </div>
      </div>

      {/* Our Story */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        <div>
          <img
            src="https://images.pexels.com/photos/3184460/pexels-photo-3184460.jpeg?auto=compress&cs=tinysrgb&w=800"
            alt="Team collaboration"
            className="rounded-xl shadow-lg"
          />
        </div>
        <div>
          <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
            Our Story
          </h3>
          <div className="space-y-4 text-gray-600 dark:text-gray-300">
            <p>
              Thrive Hub was born from a simple observation: students and professionals struggle 
              to maintain their health while juggling demanding schedules, limited budgets, and 
              high-stress environments.
            </p>
            <p>
              Our founders, a diverse team of wellness experts, technologists, and former students 
              and professionals, experienced these challenges firsthand. They realized that existing 
              wellness solutions were either too generic, too expensive, or too time-consuming.
            </p>
            <p>
              Today, Thrive Hub serves thousands of users worldwide, providing personalized wellness 
              guidance that adapts to each person's unique circumstances, goals, and preferences.
            </p>
          </div>
        </div>
      </div>

      {/* Our Values */}
      <div>
        <h3 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-8">
          Our Core Values
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value, index) => {
            const Icon = value.icon
            return (
              <div
                key={index}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 text-center shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
              >
                <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 rounded-full w-fit mx-auto mb-4">
                  <Icon className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                  {value.title}
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
                  {value.description}
                </p>
              </div>
            )
          })}
        </div>
      </div>

      {/* Team Section */}
      <div>
        <h3 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-8">
          Meet Our Expert Team
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-xl p-6 text-center shadow-sm border border-gray-200 dark:border-gray-700"
            >
              <img
                src={member.image}
                alt={member.name}
                className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
              />
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">
                {member.name}
              </h4>
              <p className="text-emerald-600 dark:text-emerald-400 font-medium mb-2">
                {member.role}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {member.expertise}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Statistics */}
      <div className="bg-gray-900 dark:bg-gray-800 rounded-2xl p-8 lg:p-12 text-white">
        <h3 className="text-3xl font-bold text-center mb-8">By the Numbers</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="text-4xl font-bold text-emerald-400 mb-2">50,000+</div>
            <div className="text-gray-300">Lives Transformed</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-emerald-400 mb-2">95%</div>
            <div className="text-gray-300">User Satisfaction</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-emerald-400 mb-2">40+</div>
            <div className="text-gray-300">Countries Served</div>
          </div>
        </div>
      </div>

      {/* Contact */}
      <div className="text-center bg-white dark:bg-gray-800 rounded-xl p-8 shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          Have Questions?
        </h3>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          We'd love to hear from you. Reach out to learn more about how Thrive Hub can support your wellness journey.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="px-6 py-3 bg-emerald-600 text-white font-medium rounded-lg hover:bg-emerald-700 transition-colors">
            Contact Support
          </button>
          <button className="px-6 py-3 border border-emerald-600 text-emerald-600 font-medium rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors">
            Schedule Demo
          </button>
        </div>
      </div>
    </div>
  )
}