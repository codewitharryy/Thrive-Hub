import React from 'react'
import { 
  Home, 
  Users, 
  Trophy, 
  User, 
  Star, 
  Info, 
  Heart,
  X,
  BookOpen,
  UserCheck,
  Gift
} from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'

interface SidebarProps {
  isOpen: boolean
  onClose: () => void
  activeSection: string
  onSectionChange: (section: string) => void
}

export function Sidebar({ isOpen, onClose, activeSection, onSectionChange }: SidebarProps) {
  const { profile } = useAuth()

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'why-join', label: 'Why Join Thrive Hub', icon: Heart },
    { id: 'about', label: 'About', icon: Info },
    { id: 'community', label: 'Community', icon: Users },
    { id: 'resources', label: 'Resources', icon: BookOpen },
    { id: 'trainers', label: 'Trainers & Experts', icon: UserCheck },
    { id: 'scoreboard', label: 'Scoreboard', icon: Trophy },
    { id: 'rewards', label: 'Rewards Store', icon: Gift },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'points', label: 'Points Earned', icon: Star },
  ]

  const handleItemClick = (sectionId: string) => {
    onSectionChange(sectionId)
    onClose()
  }

  if (!isOpen) return null

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
        onClick={onClose}
      />
      
      {/* Sidebar */}
      <div className={`fixed left-0 top-0 h-full w-80 bg-white dark:bg-gray-800 shadow-xl z-50 transform transition-all duration-300 overflow-y-auto ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-emerald-600 rounded-full flex items-center justify-center">
                <span className="text-lg font-bold text-white">TH</span>
              </div>
              <div>
                <h2 className="font-bold text-lg text-gray-900 dark:text-white">Thrive Hub</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Welcome, {profile?.full_name?.split(' ')[0] || 'User'}!
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors lg:hidden"
            >
              <X className="h-5 w-5 text-gray-600 dark:text-gray-400" />
            </button>
          </div>

          {/* Points Display */}
          <div className="bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg p-4 mb-6 text-white hover:scale-105 transition-transform duration-200 cursor-pointer">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Total Points</p>
                <p className="text-2xl font-bold">{profile?.total_points || 0}</p>
              </div>
              <Star className="h-8 w-8 opacity-90" />
            </div>
          </div>

          {/* Menu Items */}
          <nav className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon
              const isActive = activeSection === item.id
              
              return (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-all duration-200 hover:scale-105 ${
                    isActive
                      ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 shadow-md'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 hover:shadow-sm'
                  }`}
                >
                  <Icon className={`h-5 w-5 ${isActive ? 'animate-pulse' : ''}`} />
                  <span className="font-medium">{item.label}</span>
                </button>
              )
            })}
          </nav>

          {/* User Stats */}
          <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
            <div className="space-y-3">
              {profile?.bmi && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">BMI</span>
                  <span className="font-medium text-gray-900 dark:text-white">{profile.bmi}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">Activity Level</span>
                <span className="font-medium text-gray-900 dark:text-white capitalize">
                  {profile?.activity_level?.replace('_', ' ') || 'Not Set'}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">Goal</span>
                <span className="font-medium text-gray-900 dark:text-white capitalize">
                  {profile?.fitness_goal?.replace('_', ' ') || 'Not Set'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}